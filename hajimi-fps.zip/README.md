# 哈基米枪战
上传到 GitHub 仓库后，Actions 会自动构建，在 Actions → 最新一次运行 → Artifacts 下载 hajimi-fps-apk (内含 app-debug.apk)。
